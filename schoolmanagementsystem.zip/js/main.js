var image_tracker = "g1"
function changeImg(){
    var image = document.getElementById('homepic');
   
   if(image_tracker=="g1"){
       image.src = "images/IMG1.jpg";
       image_tracker = "g2";
   }else{
       image.src ="images/IMG2.jpg";
       image_tracker ="g1";
   }
}
setInterval('changeImg()',2000)

    
 function changeColour(){

       let colour = document.getElementById('colour').value;
         document.bgColor = colour; 
     }
    