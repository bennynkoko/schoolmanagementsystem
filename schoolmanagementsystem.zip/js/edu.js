
        function changeColour(){

let  colour = document.getElementById('colour').value;
document.bgColor = colour; 
}